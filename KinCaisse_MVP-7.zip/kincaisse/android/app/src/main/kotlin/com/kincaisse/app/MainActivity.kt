package com.kincaisse.app

import io.flutter.embedding.android.FlutterActivity

/**
 * Activite principale de KinCaisse.
 *
 * Utilise exclusivement le Flutter v2 Embedding via FlutterActivity
 * (io.flutter.embedding.android.FlutterActivity), conformement a
 * l'exigence technique du projet. Aucune reference a l'ancien
 * v1 embedding (io.flutter.app.FlutterActivity) n'est utilisee.
 *
 * EVOLUTION FUTURE : si des plugins natifs personnalises sont necessaires
 * (ex: integration Mobile Money via SDK natif Android), ils peuvent etre
 * enregistres ici en surchargeant configureFlutterEngine().
 */
class MainActivity : FlutterActivity()
