# Regles Proguard/R8 pour KinCaisse.
# Le minify est desactive par defaut pour ce MVP (build.gradle: minifyEnabled false).
# A activer plus tard pour la production, avec les regles Hive/Flutter Secure Storage
# ci-dessous si necessaire :

-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }
-dontwarn io.flutter.embedding.**
