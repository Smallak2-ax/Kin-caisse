import 'package:hive/hive.dart';

/// Modele Produit : represente un article en stock (medicament, parapharmacie, etc.)
///
/// NOTE: TypeAdapter ecrit a la main (pas de build_runner) pour garantir
/// une compilation fiable en environnement CI/Codemagic sans etape de
/// generation de code supplementaire.
class Product {
  String id;
  String name;
  double purchasePrice; // Prix d'achat (cout)
  double sellingPrice; // Prix de vente
  int quantity; // Quantite en stock
  int alertThreshold; // Seuil d'alerte stock bas (defaut : 5)
  DateTime createdAt;
  DateTime updatedAt;

  Product({
    required this.id,
    required this.name,
    required this.purchasePrice,
    required this.sellingPrice,
    required this.quantity,
    this.alertThreshold = 5,
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  bool get isLowStock => quantity < alertThreshold;

  Product copyWith({
    String? name,
    double? purchasePrice,
    double? sellingPrice,
    int? quantity,
    int? alertThreshold,
  }) {
    return Product(
      id: id,
      name: name ?? this.name,
      purchasePrice: purchasePrice ?? this.purchasePrice,
      sellingPrice: sellingPrice ?? this.sellingPrice,
      quantity: quantity ?? this.quantity,
      alertThreshold: alertThreshold ?? this.alertThreshold,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
    );
  }
}

/// TypeAdapter manuel pour Hive. typeId=0 reserve pour Product.
class ProductAdapter extends TypeAdapter<Product> {
  @override
  final int typeId = 0;

  @override
  Product read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Product(
      id: fields[0] as String,
      name: fields[1] as String,
      purchasePrice: fields[2] as double,
      sellingPrice: fields[3] as double,
      quantity: fields[4] as int,
      alertThreshold: fields[5] as int? ?? 5,
      createdAt: fields[6] as DateTime? ?? DateTime.now(),
      updatedAt: fields[7] as DateTime? ?? DateTime.now(),
    );
  }

  @override
  void write(BinaryWriter writer, Product obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.purchasePrice)
      ..writeByte(3)
      ..write(obj.sellingPrice)
      ..writeByte(4)
      ..write(obj.quantity)
      ..writeByte(5)
      ..write(obj.alertThreshold)
      ..writeByte(6)
      ..write(obj.createdAt)
      ..writeByte(7)
      ..write(obj.updatedAt);
  }
}
