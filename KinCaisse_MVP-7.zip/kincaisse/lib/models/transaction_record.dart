import 'package:hive/hive.dart';

/// Type de transaction financiere.
enum TransactionType { vente, depense }

/// Modele Transaction : represente une entree (vente) ou une sortie (depense)
/// dans la caisse. Chaque vente est reliee a un produit et une quantite.
class TransactionRecord {
  String id;
  TransactionType type;
  String? productId; // null pour une depense
  String? productName; // conserve en cas de suppression future du produit
  int quantity; // quantite vendue (0 pour une depense)
  double unitPrice; // prix unitaire au moment de la vente
  double totalAmount; // montant total de la transaction
  String description; // description libre (depense) ou note
  DateTime date;

  TransactionRecord({
    required this.id,
    required this.type,
    this.productId,
    this.productName,
    this.quantity = 0,
    this.unitPrice = 0,
    required this.totalAmount,
    this.description = '',
    DateTime? date,
  }) : date = date ?? DateTime.now();
}

/// TypeAdapter manuel pour Hive. typeId=1 reserve pour TransactionRecord.
class TransactionRecordAdapter extends TypeAdapter<TransactionRecord> {
  @override
  final int typeId = 1;

  @override
  TransactionRecord read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return TransactionRecord(
      id: fields[0] as String,
      type: TransactionType.values[fields[1] as int],
      productId: fields[2] as String?,
      productName: fields[3] as String?,
      quantity: fields[4] as int,
      unitPrice: fields[5] as double,
      totalAmount: fields[6] as double,
      description: fields[7] as String,
      date: fields[8] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, TransactionRecord obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.type.index)
      ..writeByte(2)
      ..write(obj.productId)
      ..writeByte(3)
      ..write(obj.productName)
      ..writeByte(4)
      ..write(obj.quantity)
      ..writeByte(5)
      ..write(obj.unitPrice)
      ..writeByte(6)
      ..write(obj.totalAmount)
      ..writeByte(7)
      ..write(obj.description)
      ..writeByte(8)
      ..write(obj.date);
  }
}
