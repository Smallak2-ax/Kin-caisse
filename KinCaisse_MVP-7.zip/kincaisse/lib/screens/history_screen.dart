import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/transaction_record.dart';
import '../services/storage_service.dart';

/// Ecran Historique : liste de toutes les ventes et depenses, triees
/// de la plus recente a la plus ancienne.
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final transactions = StorageService.instance.getAllTransactions();
    final currencyFormat = NumberFormat.currency(
      locale: 'fr_FR',
      symbol: 'FC ',
      decimalDigits: 0,
    );
    final dateFormat = DateFormat('dd/MM/yyyy HH:mm');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Historique'),
        backgroundColor: const Color(0xFF0B5D3B),
        foregroundColor: Colors.white,
      ),
      body: transactions.isEmpty
          ? const Center(
              child: Text('Aucune transaction enregistree.', style: TextStyle(color: Colors.grey)),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: transactions.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final tx = transactions[index];
                final isVente = tx.type == TransactionType.vente;
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey[200]!),
                  ),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: isVente ? Colors.green[50] : Colors.red[50],
                      child: Icon(
                        isVente ? Icons.arrow_downward : Icons.arrow_upward,
                        color: isVente ? Colors.green : Colors.red,
                      ),
                    ),
                    title: Text(
                      isVente
                          ? '${tx.productName ?? "Produit"} x${tx.quantity}'
                          : (tx.description.isEmpty ? 'Depense' : tx.description),
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    subtitle: Text(dateFormat.format(tx.date)),
                    trailing: Text(
                      '${isVente ? '+' : '-'} ${currencyFormat.format(tx.totalAmount)}',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: isVente ? Colors.green : Colors.red,
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
