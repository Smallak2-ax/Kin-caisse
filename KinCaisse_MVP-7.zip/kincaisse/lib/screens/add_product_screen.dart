import 'package:flutter/material.dart';
import '../models/product.dart';
import '../services/storage_service.dart';

/// Ecran d'ajout ou de modification d'un produit.
///
/// Si [existingProduct] est fourni, l'ecran fonctionne en mode edition.
class AddProductScreen extends StatefulWidget {
  final Product? existingProduct;
  const AddProductScreen({super.key, this.existingProduct});

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _purchasePriceController = TextEditingController();
  final _sellingPriceController = TextEditingController();
  final _quantityController = TextEditingController();

  bool get _isEditing => widget.existingProduct != null;

  @override
  void initState() {
    super.initState();
    final p = widget.existingProduct;
    if (p != null) {
      _nameController.text = p.name;
      _purchasePriceController.text = p.purchasePrice.toStringAsFixed(0);
      _sellingPriceController.text = p.sellingPrice.toStringAsFixed(0);
      _quantityController.text = p.quantity.toString();
    }
  }

  Future<void> _handleSave() async {
    if (!_formKey.currentState!.validate()) return;

    final name = _nameController.text.trim();
    final purchasePrice = double.parse(_purchasePriceController.text);
    final sellingPrice = double.parse(_sellingPriceController.text);
    final quantity = int.parse(_quantityController.text);

    if (_isEditing) {
      final updated = widget.existingProduct!.copyWith(
        name: name,
        purchasePrice: purchasePrice,
        sellingPrice: sellingPrice,
        quantity: quantity,
      );
      await StorageService.instance.updateProduct(updated);
    } else {
      final product = Product(
        id: StorageService.generateId(),
        name: name,
        purchasePrice: purchasePrice,
        sellingPrice: sellingPrice,
        quantity: quantity,
      );
      await StorageService.instance.addProduct(product);
    }

    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _handleDelete() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Supprimer le produit ?'),
        content: Text('Voulez-vous vraiment supprimer "${widget.existingProduct!.name}" ?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Supprimer', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await StorageService.instance.deleteProduct(widget.existingProduct!.id);
      if (mounted) Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Modifier le produit' : 'Nouveau produit'),
        backgroundColor: const Color(0xFF0B5D3B),
        foregroundColor: Colors.white,
        actions: [
          if (_isEditing)
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: _handleDelete,
              tooltip: 'Supprimer',
            ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Nom du produit',
                border: OutlineInputBorder(),
              ),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Le nom est obligatoire' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _purchasePriceController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: "Prix d'achat (FC)",
                border: OutlineInputBorder(),
              ),
              validator: _validatePositiveNumber,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _sellingPriceController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Prix de vente (FC)',
                border: OutlineInputBorder(),
              ),
              validator: _validatePositiveNumber,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _quantityController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Quantite en stock',
                border: OutlineInputBorder(),
              ),
              validator: _validateNonNegativeInt,
            ),
            const SizedBox(height: 28),
            SizedBox(
              height: 48,
              child: ElevatedButton(
                onPressed: _handleSave,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF0B5D3B),
                  foregroundColor: Colors.white,
                ),
                child: Text(_isEditing ? 'Enregistrer les modifications' : 'Ajouter le produit'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Validation : empeche les prix negatifs ou non numeriques.
  String? _validatePositiveNumber(String? value) {
    if (value == null || value.trim().isEmpty) return 'Champ obligatoire';
    final parsed = double.tryParse(value);
    if (parsed == null) return 'Nombre invalide';
    if (parsed < 0) return 'La valeur ne peut pas etre negative';
    return null;
  }

  /// Validation : empeche les quantites negatives ou non entieres.
  String? _validateNonNegativeInt(String? value) {
    if (value == null || value.trim().isEmpty) return 'Champ obligatoire';
    final parsed = int.tryParse(value);
    if (parsed == null) return 'Nombre entier invalide';
    if (parsed < 0) return 'La quantite ne peut pas etre negative';
    return null;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _purchasePriceController.dispose();
    _sellingPriceController.dispose();
    _quantityController.dispose();
    super.dispose();
  }
}
