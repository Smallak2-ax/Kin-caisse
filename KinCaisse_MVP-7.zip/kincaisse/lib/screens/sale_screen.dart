import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/product.dart';
import '../models/transaction_record.dart';
import '../services/storage_service.dart';

/// Ecran Nouvelle Vente.
///
/// LOGIQUE METIER CRITIQUE :
/// 1. L'utilisateur choisit un produit et une quantite.
/// 2. A la validation :
///    a. On verifie que la quantite demandee est disponible en stock.
///    b. On cree la transaction de type "vente" (entree de caisse).
///    c. On decremente automatiquement la quantite du produit
///       (nouvelle_quantite = ancienne_quantite - quantite_vendue).
///    d. Tout est fait de façon atomique du point de vue utilisateur :
///       si le stock est insuffisant, AUCUNE transaction n'est creee.
class SaleScreen extends StatefulWidget {
  const SaleScreen({super.key});

  @override
  State<SaleScreen> createState() => _SaleScreenState();
}

class _SaleScreenState extends State<SaleScreen> {
  final _formKey = GlobalKey<FormState>();
  final _quantityController = TextEditingController(text: '1');
  final _storage = StorageService.instance;
  final _currencyFormat = NumberFormat.currency(
    locale: 'fr_FR',
    symbol: 'FC ',
    decimalDigits: 0,
  );

  Product? _selectedProduct;
  bool _isSaving = false;

  double get _totalAmount {
    if (_selectedProduct == null) return 0;
    final qty = int.tryParse(_quantityController.text) ?? 0;
    return qty * _selectedProduct!.sellingPrice;
  }

  Future<void> _handleValidateSale() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedProduct == null) {
      _showSnack('Veuillez selectionner un produit.');
      return;
    }

    final quantitySold = int.parse(_quantityController.text);
    final product = _selectedProduct!;

    // --- Garde-fou : ne jamais autoriser une vente superieure au stock ---
    if (quantitySold > product.quantity) {
      _showSnack(
        'Stock insuffisant : seulement ${product.quantity} unite(s) disponible(s).',
      );
      return;
    }

    setState(() => _isSaving = true);

    // 1. Decrementer le stock (nouvelle_quantite = ancienne_quantite - qty)
    final stockUpdated = await _storage.decrementStock(product.id, quantitySold);

    if (!stockUpdated) {
      setState(() => _isSaving = false);
      _showSnack('Erreur : impossible de mettre a jour le stock.');
      return;
    }

    // 2. Creer la transaction de type "vente" (entree de caisse)
    final totalAmount = quantitySold * product.sellingPrice;
    final transaction = TransactionRecord(
      id: StorageService.generateId(),
      type: TransactionType.vente,
      productId: product.id,
      productName: product.name,
      quantity: quantitySold,
      unitPrice: product.sellingPrice,
      totalAmount: totalAmount,
      description: 'Vente de $quantitySold x ${product.name}',
    );
    await _storage.addTransaction(transaction);

    setState(() => _isSaving = false);

    if (mounted) {
      _showSnack('Vente enregistree avec succes.', success: true);
      Navigator.of(context).pop();
    }
  }

  void _showSnack(String message, {bool success = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final products = _storage.getAllProducts().where((p) => p.quantity > 0).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Nouvelle Vente'),
        backgroundColor: const Color(0xFF0B5D3B),
        foregroundColor: Colors.white,
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (products.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 40),
                child: Text(
                  "Aucun produit disponible en stock.\nAjoutez d'abord des produits.",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey),
                ),
              )
            else ...[
              DropdownButtonFormField<Product>(
                value: _selectedProduct,
                decoration: const InputDecoration(
                  labelText: 'Produit',
                  border: OutlineInputBorder(),
                ),
                items: products
                    .map((p) => DropdownMenuItem(
                          value: p,
                          child: Text('${p.name} (stock: ${p.quantity})'),
                        ))
                    .toList(),
                onChanged: (p) => setState(() {
                  _selectedProduct = p;
                  _quantityController.text = '1';
                }),
                validator: (v) => v == null ? 'Selectionnez un produit' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _quantityController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Quantite vendue',
                  border: OutlineInputBorder(),
                ),
                onChanged: (_) => setState(() {}),
                validator: (value) {
                  final qty = int.tryParse(value ?? '');
                  if (qty == null || qty <= 0) return 'Quantite invalide';
                  if (_selectedProduct != null && qty > _selectedProduct!.quantity) {
                    return 'Depasse le stock disponible (${_selectedProduct!.quantity})';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF0B5D3B).withOpacity(0.08),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Montant total', style: TextStyle(fontWeight: FontWeight.w600)),
                    Text(
                      _currencyFormat.format(_totalAmount),
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF0B5D3B),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),
              SizedBox(
                height: 48,
                child: ElevatedButton(
                  onPressed: _isSaving ? null : _handleValidateSale,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0B5D3B),
                    foregroundColor: Colors.white,
                  ),
                  child: _isSaving
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : const Text('Valider la vente'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _quantityController.dispose();
    super.dispose();
  }
}
