import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/product.dart';
import '../services/storage_service.dart';
import 'add_product_screen.dart';

/// Ecran Liste des Produits / Gestion du Stock.
class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  final _storage = StorageService.instance;
  final _currencyFormat = NumberFormat.currency(
    locale: 'fr_FR',
    symbol: 'FC ',
    decimalDigits: 0,
  );

  void _refresh() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final products = _storage.getAllProducts();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Produits / Stock'),
        backgroundColor: const Color(0xFF0B5D3B),
        foregroundColor: Colors.white,
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFF0B5D3B),
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Ajouter', style: TextStyle(color: Colors.white)),
        onPressed: () async {
          await Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const AddProductScreen()),
          );
          _refresh();
        },
      ),
      body: products.isEmpty
          ? const Center(
              child: Text(
                'Aucun produit enregistre.\nAppuyez sur "Ajouter" pour commencer.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: products.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final p = products[index];
                return _buildProductTile(p);
              },
            ),
    );
  }

  Widget _buildProductTile(Product p) {
    final isLow = p.isLowStock;
    return Container(
      decoration: BoxDecoration(
        color: isLow ? Colors.red[50] : Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: isLow ? Colors.red[200]! : Colors.grey[200]!),
      ),
      child: ListTile(
        title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(
          'Achat: ${_currencyFormat.format(p.purchasePrice)} | '
          'Vente: ${_currencyFormat.format(p.sellingPrice)}',
          style: const TextStyle(fontSize: 12),
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              '${p.quantity}',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: isLow ? Colors.red : Colors.black87,
              ),
            ),
            Text(
              'en stock',
              style: TextStyle(fontSize: 10, color: isLow ? Colors.red : Colors.grey),
            ),
          ],
        ),
        onTap: () async {
          await Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => AddProductScreen(existingProduct: p)),
          );
          _refresh();
        },
      ),
    );
  }
}
