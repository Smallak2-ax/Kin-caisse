import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/storage_service.dart';
import 'products_screen.dart';
import 'sale_screen.dart';
import 'history_screen.dart';
import 'expense_screen.dart';

/// Ecran principal : tableau de bord avec solde, totaux et alertes.
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final _storage = StorageService.instance;
  final _currencyFormat = NumberFormat.currency(
    locale: 'fr_FR',
    symbol: 'FC ',
    decimalDigits: 0,
  );

  void _refresh() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final solde = _storage.getSolde();
    final entrees = _storage.getTotalEntrees();
    final sorties = _storage.getTotalSorties();
    final lowStock = _storage.getLowStockProducts();

    return Scaffold(
      appBar: AppBar(
        title: const Text('KinCaisse'),
        backgroundColor: const Color(0xFF0B5D3B),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refresh,
            tooltip: 'Actualiser',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async => _refresh(),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildSoldeCard(solde),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildStatCard(
                    label: 'Total Entrees',
                    value: entrees,
                    color: Colors.green,
                    icon: Icons.arrow_downward,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildStatCard(
                    label: 'Total Sorties',
                    value: sorties,
                    color: Colors.red,
                    icon: Icons.arrow_upward,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            if (lowStock.isNotEmpty) _buildLowStockAlert(lowStock.length),
            const SizedBox(height: 24),
            const Text(
              'Actions rapides',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.3,
              children: [
                _buildActionButton(
                  icon: Icons.point_of_sale,
                  label: 'Nouvelle Vente',
                  color: const Color(0xFF0B5D3B),
                  onTap: () => _openScreen(const SaleScreen()),
                ),
                _buildActionButton(
                  icon: Icons.money_off,
                  label: 'Nouvelle Depense',
                  color: Colors.orange[800]!,
                  onTap: () => _openScreen(const ExpenseScreen()),
                ),
                _buildActionButton(
                  icon: Icons.inventory_2,
                  label: 'Produits / Stock',
                  color: Colors.blueGrey[700]!,
                  onTap: () => _openScreen(const ProductsScreen()),
                ),
                _buildActionButton(
                  icon: Icons.history,
                  label: 'Historique',
                  color: Colors.deepPurple,
                  onTap: () => _openScreen(const HistoryScreen()),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _openScreen(Widget screen) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
    _refresh(); // rafraichir les chiffres au retour
  }

  Widget _buildSoldeCard(double solde) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF0B5D3B),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Solde de caisse', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text(
            _currencyFormat.format(solde),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard({
    required String label,
    required double value,
    required Color color,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color),
          const SizedBox(height: 8),
          Text(label, style: TextStyle(color: color.withOpacity(0.8), fontSize: 12)),
          const SizedBox(height: 4),
          Text(
            _currencyFormat.format(value),
            style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 15),
          ),
        ],
      ),
    );
  }

  Widget _buildLowStockAlert(int count) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.red[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.red[200]!),
      ),
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded, color: Colors.red),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              '$count produit(s) en stock bas (< 5 unites)',
              style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w600),
            ),
          ),
          TextButton(
            onPressed: () => _openScreen(const ProductsScreen()),
            child: const Text('Voir'),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: color,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.white, size: 30),
              const SizedBox(height: 8),
              Text(
                label,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
