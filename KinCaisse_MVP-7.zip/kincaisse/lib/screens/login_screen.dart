import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/auth_service.dart';
import 'dashboard_screen.dart';

/// Ecran de connexion par PIN a 4 chiffres.
///
/// - Si aucun PIN n'existe encore (premier lancement), l'ecran demande
///   de creer un PIN puis de le confirmer.
/// - Sinon, il demande simplement de saisir le PIN existant.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _pinController = TextEditingController();
  final TextEditingController _confirmController = TextEditingController();

  bool _loading = true;
  bool _hasPin = false;
  bool _isConfirmStep = false;
  String _firstPin = '';
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _checkPinStatus();
  }

  Future<void> _checkPinStatus() async {
    final hasPin = await AuthService.instance.hasPinConfigured();
    setState(() {
      _hasPin = hasPin;
      _loading = false;
    });
  }

  Future<void> _handleSubmit() async {
    final enteredPin = _pinController.text;

    if (enteredPin.length != 4) {
      setState(() => _errorMessage = 'Le PIN doit contenir 4 chiffres.');
      return;
    }

    if (!_hasPin) {
      // --- Flux de creation de PIN (premier lancement) ---
      if (!_isConfirmStep) {
        setState(() {
          _firstPin = enteredPin;
          _isConfirmStep = true;
          _pinController.clear();
          _errorMessage = null;
        });
        return;
      } else {
        if (enteredPin != _firstPin) {
          setState(() {
            _errorMessage = 'Les deux PIN ne correspondent pas. Reessayez.';
            _isConfirmStep = false;
            _firstPin = '';
            _pinController.clear();
          });
          return;
        }
        await AuthService.instance.setPin(enteredPin);
        _navigateToDashboard();
        return;
      }
    }

    // --- Flux de verification (utilisateur existant) ---
    final isValid = await AuthService.instance.verifyPin(enteredPin);
    if (isValid) {
      _navigateToDashboard();
    } else {
      setState(() {
        _errorMessage = 'PIN incorrect. Reessayez.';
        _pinController.clear();
      });
    }
  }

  void _navigateToDashboard() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const DashboardScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final title = !_hasPin
        ? (_isConfirmStep ? 'Confirmez votre PIN' : 'Creez votre PIN (4 chiffres)')
        : 'Entrez votre PIN';

    return Scaffold(
      backgroundColor: const Color(0xFF0B5D3B),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.local_pharmacy, size: 72, color: Colors.white),
              const SizedBox(height: 12),
              const Text(
                'KinCaisse',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Text(
                'Gestion de caisse & stock pour officines',
                style: TextStyle(color: Colors.white70, fontSize: 13),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 40),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: _pinController,
                keyboardType: TextInputType.number,
                obscureText: true,
                maxLength: 4,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 28, letterSpacing: 16),
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(4),
                ],
                decoration: InputDecoration(
                  counterText: '',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
                onSubmitted: (_) => _handleSubmit(),
              ),
              if (_errorMessage != null) ...[
                const SizedBox(height: 12),
                Text(
                  _errorMessage!,
                  style: const TextStyle(color: Colors.redAccent),
                  textAlign: TextAlign.center,
                ),
              ],
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: _handleSubmit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: const Color(0xFF0B5D3B),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    !_hasPin
                        ? (_isConfirmStep ? 'Confirmer' : 'Continuer')
                        : 'Valider',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _pinController.dispose();
    _confirmController.dispose();
    super.dispose();
  }
}
