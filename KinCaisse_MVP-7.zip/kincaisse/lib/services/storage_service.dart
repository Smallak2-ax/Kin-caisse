import 'dart:convert';
import 'dart:math';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/product.dart';
import '../models/transaction_record.dart';

/// Service central de stockage.
///
/// Responsabilites :
/// - Generer / recuperer la cle de chiffrement AES-256 utilisee par Hive
///   (la cle elle-meme est stockee dans flutter_secure_storage, qui
///   s'appuie sur le Keystore Android / Keychain iOS).
/// - Ouvrir les boites Hive chiffrees (produits, transactions).
/// - Fournir des methodes CRUD simples aux ecrans.
///
/// SECURITE :
/// - Aucune valeur sensible (montant, PIN) n'est jamais loguee (pas de
///   print()/debugPrint() sur les objets Product/TransactionRecord).
/// - La base Hive est chiffree via HiveAesCipher avec une cle 256 bits.
class StorageService {
  StorageService._internal();
  static final StorageService instance = StorageService._internal();

  static const _secureStorage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const _hiveKeyStorageKey = 'kincaisse_hive_encryption_key_v1';

  late Box<Product> productsBox;
  late Box<TransactionRecord> transactionsBox;

  bool _initialized = false;
  bool get isInitialized => _initialized;

  /// Initialise Hive avec une base chiffree. A appeler une seule fois
  /// au demarrage de l'application (apres Hive.initFlutter()).
  Future<void> init() async {
    if (_initialized) return;

    if (!Hive.isAdapterRegistered(0)) {
      Hive.registerAdapter(ProductAdapter());
    }
    if (!Hive.isAdapterRegistered(1)) {
      Hive.registerAdapter(TransactionRecordAdapter());
    }

    final encryptionKey = await _getOrCreateEncryptionKey();
    final cipher = HiveAesCipher(encryptionKey);

    productsBox = await Hive.openBox<Product>(
      'products_box',
      encryptionCipher: cipher,
    );
    transactionsBox = await Hive.openBox<TransactionRecord>(
      'transactions_box',
      encryptionCipher: cipher,
    );

    _initialized = true;
  }

  /// Recupere la cle de chiffrement AES-256 depuis le stockage securise,
  /// ou en genere une nouvelle si absente (premier lancement).
  Future<List<int>> _getOrCreateEncryptionKey() async {
    final existing = await _secureStorage.read(key: _hiveKeyStorageKey);
    if (existing != null) {
      return base64Url.decode(existing);
    }
    final key = Hive.generateSecureKey(); // 256 bits
    await _secureStorage.write(
      key: _hiveKeyStorageKey,
      value: base64UrlEncode(key),
    );
    return key;
  }

  // ---------------------------------------------------------------------
  // PRODUITS
  // ---------------------------------------------------------------------

  List<Product> getAllProducts() => productsBox.values.toList()
    ..sort((a, b) => a.name.compareTo(b.name));

  List<Product> getLowStockProducts() =>
      getAllProducts().where((p) => p.isLowStock).toList();

  Future<void> addProduct(Product product) async {
    await productsBox.put(product.id, product);
  }

  Future<void> updateProduct(Product product) async {
    await productsBox.put(product.id, product);
  }

  Future<void> deleteProduct(String id) async {
    await productsBox.delete(id);
  }

  Product? getProductById(String id) => productsBox.get(id);

  /// REGLE METIER CRITIQUE : decremente le stock d'un produit apres une
  /// vente. Retourne false si le stock est insuffisant (empeche les
  /// quantites negatives).
  Future<bool> decrementStock(String productId, int quantitySold) async {
    final product = productsBox.get(productId);
    if (product == null) return false;
    if (quantitySold <= 0) return false;
    if (product.quantity - quantitySold < 0) return false; // garde-fou

    final updated = product.copyWith(quantity: product.quantity - quantitySold);
    await productsBox.put(productId, updated);
    return true;
  }

  // ---------------------------------------------------------------------
  // TRANSACTIONS (ventes / depenses)
  // ---------------------------------------------------------------------

  List<TransactionRecord> getAllTransactions() {
    final list = transactionsBox.values.toList();
    list.sort((a, b) => b.date.compareTo(a.date)); // plus recent d'abord
    return list;
  }

  Future<void> addTransaction(TransactionRecord tx) async {
    await transactionsBox.put(tx.id, tx);
  }

  double getTotalEntrees() {
    return transactionsBox.values
        .where((t) => t.type == TransactionType.vente)
        .fold(0.0, (sum, t) => sum + t.totalAmount);
  }

  double getTotalSorties() {
    return transactionsBox.values
        .where((t) => t.type == TransactionType.depense)
        .fold(0.0, (sum, t) => sum + t.totalAmount);
  }

  double getSolde() => getTotalEntrees() - getTotalSorties();

  /// Genere un identifiant unique simple (sans dependance externe lourde).
  static String generateId() {
    final rand = Random.secure();
    final timestamp = DateTime.now().microsecondsSinceEpoch;
    final suffix = rand.nextInt(999999);
    return '$timestamp-$suffix';
  }
}
