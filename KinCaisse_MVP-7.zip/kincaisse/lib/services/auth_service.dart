import 'dart:convert';
import 'package:crypto/crypto.dart' as crypto;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Service d'authentification par code PIN (4 chiffres).
///
/// Le PIN n'est jamais stocke en clair : on stocke uniquement son
/// empreinte SHA-256 (salee) dans flutter_secure_storage.
///
/// EVOLUTION FUTURE (Firebase Auth) :
/// -----------------------------------------------------------------
/// Pour brancher Firebase Auth plus tard (multi-pharmacien, multi-poste,
/// synchronisation cloud), remplacer ce service par un wrapper autour de
/// firebase_auth :
///   - signInWithPin() -> signInWithEmailAndPassword() ou
///     signInWithCustomToken() (token genere par un backend qui valide
///     le PIN cote serveur).
///   - Le PIN local resterait utilisable comme verrou rapide de session
///     (app lock) meme apres une connexion Firebase, en mode hors-ligne.
/// -----------------------------------------------------------------
class AuthService {
  AuthService._internal();
  static final AuthService instance = AuthService._internal();

  static const _secureStorage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const _pinHashKey = 'kincaisse_pin_hash_v1';
  static const _pinSaltKey = 'kincaisse_pin_salt_v1';

  /// Indique si un PIN a deja ete configure (premier lancement sinon).
  Future<bool> hasPinConfigured() async {
    final hash = await _secureStorage.read(key: _pinHashKey);
    return hash != null;
  }

  /// Configure (ou reinitialise) le PIN. Doit contenir exactement 4 chiffres.
  Future<void> setPin(String pin) async {
    if (!_isValidPin(pin)) {
      throw ArgumentError('Le PIN doit contenir exactement 4 chiffres.');
    }
    final salt = _generateSalt();
    final hash = _hashPin(pin, salt);
    await _secureStorage.write(key: _pinSaltKey, value: salt);
    await _secureStorage.write(key: _pinHashKey, value: hash);
  }

  /// Verifie le PIN saisi contre le hash stocke. Ne logue jamais le PIN.
  Future<bool> verifyPin(String pin) async {
    if (!_isValidPin(pin)) return false;
    final storedHash = await _secureStorage.read(key: _pinHashKey);
    final salt = await _secureStorage.read(key: _pinSaltKey);
    if (storedHash == null || salt == null) return false;
    final computedHash = _hashPin(pin, salt);
    return computedHash == storedHash;
  }

  bool _isValidPin(String pin) => RegExp(r'^\d{4}$').hasMatch(pin);

  String _generateSalt() {
    final now = DateTime.now().microsecondsSinceEpoch.toString();
    return base64Url.encode(utf8.encode(now));
  }

  String _hashPin(String pin, String salt) {
    final bytes = utf8.encode('$salt::$pin::kincaisse');
    return crypto.sha256.convert(bytes).toString();
  }

  /// Efface completement les identifiants (deconnexion definitive / reset).
  Future<void> clearCredentials() async {
    await _secureStorage.delete(key: _pinHashKey);
    await _secureStorage.delete(key: _pinSaltKey);
  }
}
