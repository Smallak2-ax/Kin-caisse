import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'services/storage_service.dart';
import 'screens/login_screen.dart';

/// Point d'entree de l'application KinCaisse.
///
/// Initialise :
/// 1. Hive (base locale) + repertoire de stockage.
/// 2. Le StorageService (ouvre les boites chiffrees).
/// 3. Les donnees de locale pour le formatage des dates/montants en francais.
///
/// EVOLUTION FUTURE : c'est ICI que l'on initialiserait Firebase
/// (Firebase.initializeApp()) si l'on active Firebase Auth / Firestore
/// pour une synchronisation multi-appareils.
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1. Initialisation de Hive (stockage local NoSQL embarque)
  await Hive.initFlutter();

  // 2. Ouverture des boites chiffrees (cle géré via flutter_secure_storage)
  await StorageService.instance.init();

  // 3. Locale francaise pour le formatage des dates
  await initializeDateFormatting('fr_FR', null);

  runApp(const KinCaisseApp());
}

class KinCaisseApp extends StatelessWidget {
  const KinCaisseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KinCaisse',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFF0B5D3B),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0B5D3B),
          primary: const Color(0xFF0B5D3B),
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
        inputDecorationTheme: const InputDecorationTheme(
          floatingLabelBehavior: FloatingLabelBehavior.auto,
        ),
      ),
      // L'ecran de connexion (PIN) est toujours le premier ecran affiche,
      // conformement a l'exigence de securite : PIN demande a chaque
      // ouverture de l'application.
      home: const LoginScreen(),
    );
  }
}
