# KinCaisse — MVP

Application Flutter de gestion de caisse et de stock pour officines a
Kinshasa. Fonctionne entierement hors-ligne (Hive chiffre), sans backend.

## Build local

```bash
flutter pub get
flutter build apk --release
```

L'APK genere se trouve dans :
`build/app/outputs/flutter-apk/app-release.apk`

> Note : au premier `flutter build apk`, Flutter genere automatiquement les
> fichiers `gradlew` / `gradle-wrapper.jar` manquants dans `android/` a
> partir de son propre SDK — c'est normal et attendu, aucune action requise.

## Build sur Codemagic

Le fichier `codemagic.yaml` fourni est pret a l'emploi : ajoutez le repo a
Codemagic, selectionnez le workflow `kincaisse-android-apk`, et lancez le
build. L'APK release sera disponible en artefact.

## Structure du projet

```
lib/
  main.dart                 -> point d'entree, init Hive chiffre
  models/
    product.dart             -> modele Produit + TypeAdapter Hive manuel
    transaction_record.dart  -> modele Transaction + TypeAdapter Hive manuel
  services/
    storage_service.dart     -> CRUD Hive, cle de chiffrement securisee
    auth_service.dart        -> gestion du PIN (hash SHA-256 sale)
  screens/
    login_screen.dart        -> ecran PIN (creation + verification)
    dashboard_screen.dart    -> tableau de bord
    products_screen.dart     -> liste des produits / stock
    add_product_screen.dart  -> ajout / modification / suppression produit
    sale_screen.dart         -> nouvelle vente (decremente le stock)
    expense_screen.dart      -> nouvelle depense
    history_screen.dart      -> historique des transactions
```

## Securite

- Le PIN n'est jamais stocke en clair : seul son empreinte SHA-256 salee
  est conservee, dans `flutter_secure_storage` (Android Keystore).
- La base Hive est chiffree en AES-256 (`HiveAesCipher`) ; la cle est
  elle-meme stockee dans `flutter_secure_storage`.
- Toutes les entrees numeriques (prix, quantites) sont validees pour
  interdire les valeurs negatives.
- Aucun montant ni PIN n'est jamais ecrit dans les logs.

## Evolutions prevues (hors MVP)

- Remplacement du PIN local par Firebase Auth (voir commentaires dans
  `auth_service.dart`) pour la gestion multi-poste / multi-pharmacien.
- Integration Mobile Money (Vodacom M-Pesa, Airtel Money).
- Synchronisation cloud et mode multi-devises (CDF / USD).
- Module de reconnaissance photo IA (anti-contrefacon).
